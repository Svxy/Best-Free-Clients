FCK client is a free client with a payed version that unlocks pen crashers and other various features. To purchace full access, go to: https://discord.gg/7ryJgHbVwC

To install: Simply drag and drop fvrchatcp.exe into your VRChat archive (not mods folder userdata or melonloader), run vrc and you'll see a console appear and go away. just load up the game and login from your settings.

-Cutiey