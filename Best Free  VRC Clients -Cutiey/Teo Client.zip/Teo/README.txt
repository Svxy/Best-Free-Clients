easiest install ever..

step 1: drag and drop teoloader.dll into ur mods folder 
(mind you this is after you have downloaded melonloader and chosen whichever mods/clients/plugins you want)

step 2: go to This PC>(whichever drive you have vrc installed on)>Program Files(x86)>Steam>steamapps>common>VRChat>MelonLoader>Dependencies
and replace bootstrap.dll with the one provided.

FOR OCULUS:

just go to :\Program Files\Oculus\Software\Software\vrchat-vrchat and its pretty much identical 
